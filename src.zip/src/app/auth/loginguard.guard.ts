import { CanActivateFn } from '@angular/router';

export const loginguardGuard: CanActivateFn = (route, state) => {
  return true;
};
